package com.i4rt.temperaturecontrol.databaseInterfaces;

import org.springframework.stereotype.Repository;

@Repository
public interface WarningLogRecordRepo {
}
