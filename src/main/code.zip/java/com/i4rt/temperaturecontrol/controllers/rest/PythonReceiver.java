package com.i4rt.temperaturecontrol.controllers.rest;

import org.springframework.stereotype.Controller;

@Controller
public class PythonReceiver {
}
